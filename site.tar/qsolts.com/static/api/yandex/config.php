<?php
 
	$configs = array();
	$configs['shopId'] 			= '187448';
	$configs['scId'] 			= '714661';
	$configs['ShopPassword'] 	= 'Antondob7565875';
?>